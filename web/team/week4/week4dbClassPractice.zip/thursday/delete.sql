DROP TABLE w4_order_menu_items;
DROP TABLE w4_order;
DROP TABLE w4_customer;
DROP TABLE w4_menu_item;
DROP TABLE w4_restaurant;