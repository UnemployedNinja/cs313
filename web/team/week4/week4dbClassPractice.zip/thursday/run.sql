\i delete.sql 
\i create.sql
\i insert.sql
\i query.sql
