\echo '*********************List all restaurant names*********************'
-- write your query here

\echo '****************List restaurant names and addresses****************'
-- write your query here

\echo '************************List  all customers************************'
-- write your query here

\echo '**List  all menu item names and prices of a particular restaurant**'
-- write your query here

\echo '*View all orders of a particular customer - show the customer name*'
-- write your query here

\echo '************List  all orders of a particular restaurant************'
-- write your query here


