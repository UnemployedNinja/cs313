10% extra credit
   Provide code for all of the commented sections in index.php, insert.php and notes.php

Additional 10% extra credit 
   Make a professional page for displaying all students and how many notes they have, then have a link that takes them to all of their notes.


